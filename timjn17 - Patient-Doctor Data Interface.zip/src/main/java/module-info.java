module com.example.homework_3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires jdk.compiler;
    requires java.desktop;
    requires javafx.graphics;


    opens com.example.homework_3 to javafx.fxml;
    exports com.example.homework_3;
    exports com.example.homework_3.ChartPackage;
    //exports com.example.homework_3.ChartPackage;
}