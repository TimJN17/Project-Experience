package com.example.homework_3.PatientPackage;

/*import ChartPackage.Chart;
import ChartPackage.HealthItem;
import DoctorPackage.Doctor;*/
import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;

public class Patient {
    //This class is the parent class created for every patient object. Based off the provided UML diagram,
    //this class is related to PatientPackage.PatientList through composition. This class is what enables the healthcare worker
    //to access or create patient objects.

    private String firstName, lastName, id, address;
    private int age;
    Chart chart;
    Doctor doc;

    public Patient() {
        //Default constructor for patient objects.
        this.firstName = "";
        this.lastName = "";
        this.id = "";
        this.address = "";
        this.age = -1;
        chart = null;
    }

    public Patient(String firstName, String lastName, String id, String address, int age, Doctor doc) {
        //overloaded constructor for patient objects
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
        this.address = address;
        this.age = age;
        this.doc = doc;
        this.chart = new Chart(this.id, doc);
        chart.loadFromFile();
    }

    //The below are all getters and setters and go what their name implies for their respective objects
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Chart getChart() { return chart; }

    public void setChart(Chart chart) { this.chart = chart; }

    public Doctor getDoctor() { return doc; }

    public void setDoctor(Doctor doc) { this.doc = doc; }

    @Override
    public String toString() {
        return String.format("%10s %10s %5s %20s %3d %5s",
                firstName, lastName, id, address, age, doc.getId());
    }

    public String toCSV() {
        return new String(firstName + "," + lastName + "," + id + "," + address + "," + age)
                + "," + chart.getDoctor().getId();
    }

    public void showChart() {
        chart.display();
    }

    public void appendHealthItem(HealthItem h) {
        chart.append(h);
    }

    public void updateChart() {
        chart.writeToFile();
    }

}
