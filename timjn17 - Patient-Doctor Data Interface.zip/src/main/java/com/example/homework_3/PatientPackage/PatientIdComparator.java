package com.example.homework_3.PatientPackage;

import java.util.Comparator;
import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;

public class PatientIdComparator implements Comparator<Patient> {

    //This class is the class that enables the comparison and subsequent sorting of patient objects by their IDs.

    @Override
    public int compare(Patient patient1, Patient patient2) {
        return Integer.parseInt(patient1.getId()) - Integer.parseInt(patient2.getId());
    }
}
