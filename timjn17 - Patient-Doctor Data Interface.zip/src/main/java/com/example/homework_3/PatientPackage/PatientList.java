package com.example.homework_3.PatientPackage;

/*import ChartPackage.Chart;
import DoctorPackage.Doctor;
import DoctorPackage.DoctorList;*/
//import com.sun.source.doctree.DocCommentTree;
import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class PatientList  {
    //This class is structured to record a list of all the patients a healthcare worker may need to access
    //while performing his or her duties. This class uses various methods to access patient files, write o patient files
    //add patients to a list or find a patient in the list.

    // nned a getter for the number of patients in the list to return the size of the array list.
    // use STring.valueof to format the integer into a string

    public static Scanner scanner = new Scanner(System.in);
    private ArrayList<Patient> patientList;
    private String fileName;
    private Patient patient;
    private DoctorList doctorList;
    private Map<String, Patient> patientMap;


    public PatientList(String fileName) {
        //This method is the overloaded constructor for the patientList arrayList
        this.fileName = fileName;
        this.patientList = new ArrayList<>();
        this.doctorList = null;
        this.patientMap = new HashMap<>();

    }

    public void loadFromFile(File file) {
        // Your code here
        //This method accesses the patent's file. It is slightly different than the
        //accessed method of the same name in the 'ChartPackage.Chart' class. This difference allows for multiple charts to be
        //but since there is only one patient file, we can just hard-code the patient file.
        //File filename = new File("patients.csv");
        Scanner fileScanner = null;
        try{fileScanner = new Scanner(file);}
        catch(FileNotFoundException e){e.printStackTrace();}
        while(fileScanner.hasNextLine()) {
            Doctor noDoc = null;
            String line = fileScanner.nextLine();
            String [] data = line.split(",");
            //The following two lines check for a doctorID in the 'patients.csv' file and use the.getID() method in
            //the Doctor class to capture that doctor object and attach its reference to the patient object. If no
            //doctor object is found, that doctor object is assigned the reference of the doctor in the zeroth position
            //in the doctorList ArrayList
            if (data.length == 6) {noDoc = doctorList.findByID(data[5]);}
            if (data.length < 6 || noDoc == null) {noDoc = doctorList.getDoctorList().get(0);}
            Patient patient = new Patient(data[0], data[1],  data[2], data[3], Integer.parseInt(data[4]), noDoc);
            append(patient);
        } fileScanner.close();
    }

    public void writeToFile() {
        // Your code here
        //This method opens the patientList arrayList and writes information into a comma separated variable
        //file for each patient in the list
        try (PrintWriter patientWriter = new PrintWriter(fileName)) {
            for (Patient patient : patientList) {
                patientWriter.write(patient.toCSV() + "\n");
            }
        }
        catch(IOException e){e.printStackTrace();}
    }

    public void append(Patient p) {
        // Your code here
        //This simple method simply adds a patient object into the patientList.
        patientList.add(p);
        patientMap.put(p.getId(), p);
    }

    public Patient findByName(String firstName, String lastName) {
        Patient p = null;
        // Your code here
        //This method searches the patient list for patient objects by their first and last name.
        //It returns a true or false boolean condition depending on if that patient was found or not.
        for (Patient patient : patientList) {
            if (patient.getFirstName().equals(firstName) && patient.getLastName().equals(lastName)) {
                return patient;
            }
        }
        return p;
    }

    public Patient findByID(String id) {
        // Your code here
        //This method searches the patientLit array list for patient objects by their IDs
        //and returns a boolean condition depending on if that patient was found or not.
        /*for (Patient patient : patientList) {
            if (patient.getId().equals(id)) {
                return patient;
            }
        }*/
        if (patientMap.get(id) != null) {
            return patientMap.get(id);
        } else {
            return null;
        }
    }

    public void display() {
        //This method displays every patient object in the patient array list.
        if (patientList.size() == 0) {
            System.out.println("PatientPackage.Patient list is empty");
            return;
        } else {
            System.out.printf("%10s %10s %5s %20s %3s %5s\n", "First Name", "Last Name", "ID", "Address",
                    "Age", "Doctor ID");
            // Your code here
            for (Patient patient : patientList) {
                if (patient != null) {
                    System.out.println(patient);
                }
            }
        }
    }

    public void sortByPatientId( ) {
        //This class numerically sorts the patients in descending order by their ID. It uses a separate class that
        // implements Comparator.
        if (patientList.size() == 0) {
            System.out.println("There are no patients in the patientList.");
        } else {
            Collections.sort(patientList, new PatientIdComparator());
        }
    }

    public void sortByName( ) {
        //This class alphabetically sorts the patients in descending order by their last names. It uses a separate class
        // that implements Comparator.
        if (patientList.size() == 0) {
            System.out.println("There are no patients in the patientList.");
        } else {
            Collections.sort(patientList, new PatientLNameComparator());
        }
    }

    public Patient removePatient(String patientID){
        //This class removes a patient from the patientList ArrayList and deletes the .csv file created to store the
        //healthItems for the patient in a chart ArrayList.
        patient = findByID(patientID);
        if (patient != null) {
            System.out.println("\nRemoving this patient from the list and deleting their file:");
            File f = new File("HI" + patientID + ".csv");
            f.delete();
            patientList.remove(patient);
            System.out.println("\nYour patient removed successfully.");
            return patient;
        } else  {
            System.out.println("Your patient not found.");
            return null;
        }
    }

    public int patientListCount(){
        return patientList.size();
    }

    public DoctorList getDoctorList() {
        return doctorList;
    }

    public void setDoctorList(DoctorList dList) {
        this.doctorList = dList;
    }

    public ArrayList<Patient> getPatientList() {
        return patientList;
    }

    public void setPatientList(ArrayList<Patient> patientList) {
        this.patientList = patientList;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public Map<String, Patient> getPatientMap() {
        return patientMap;
    }

    public void setPatientMap(Map<String, Patient> patientMap) {
        this.patientMap = patientMap;
    }
}

