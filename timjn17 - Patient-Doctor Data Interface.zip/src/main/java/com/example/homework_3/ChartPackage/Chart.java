package com.example.homework_3.ChartPackage;

/*import DoctorPackage.Doctor;
import DoctorPackage.Surgeon;*/

import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class Chart {
    //According to the provided UML diagram, this class is related to patient through composition.
    //This class is what enables the program to access and write to HealthItem files. The chart class
    //is the mechanism through which the heath care worker can access the information about the patients.

    private ArrayList<HealthItem> chart;
    private String id;
    private String filename;
    private Doctor doctor;
    //private ArrayList<File> chartFiles;

    /*public Chart(File file) {
        // Your code here
        //This is the overloaded constructor for the ChartPackage.Chart Objects
        this.id = id;
        this.filename = "HI" + id + ".csv";
        this.chart = new ArrayList<>();
        this.doctor = doctor;
    }*/
    public Chart(String id, Doctor doctor) {
        // Your code here
        //This is the overloaded constructor for the ChartPackage.Chart Objects
        this.id = id;
        this.filename = "HI" + id + ".csv";
        this.chart = new ArrayList<>();
        this.doctor = doctor;
    }

    public void loadFromFile() {
        // Your code here
        //This method accesses a determined filename, which uses user input in the Main() method in the "HW2Driver"class
        //and accesses each line of the file. It then splits the data by any commas, creates a String array of those objects,
        //and then creates a healthItem with that string array. Finally, this method adds that ChartPackage.ChartPackage.HealthItem object to the
        //Health item arraylist  created in the ChartPackage.ChartPackage.HealthItem class.
        File newFile = new File(filename);
        Scanner fileScanner = null;
        try {
            fileScanner = new Scanner(newFile);
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] data = line.split(",");
                HealthItem item = new HealthItem(data[0], data[1], data[2], data[3]);
                append(item);
            } fileScanner.close();
        }catch(FileNotFoundException e){
                //System.out.println("\nChartPackage.Chart not found for patient "+filename+".\n");

        }
    }

    public void append(HealthItem healthItem) {
        // Your code here
        //Adds the healthItem object to the healthItem ArrayList
        chart.add(healthItem);
    }

    public void display() {
        //This method displays the HealthItems in the art array list.
        if (chart.size() == 0 ) {
            System.out.println("No chart for this patient"); return; }
        System.out.println("\n Attending doctor: " + getDoctor().getSpecialty() + " " + getDoctor().getName() +
                " " + getDoctor().getId() + "\n");
        System.out.printf("%5s %20s %15s %20s \n", "ID", "Test Name", "Date", "Value");
        for (HealthItem h : chart) {
            //NOTE: Per guidance, the doctor will not change depending on the testName.
            System.out.println(h.toString());
       }
        // The below method uses the Abstract Doctor class and subsequent method to print what the treatment plan
        // will be for the patient and their health items.
        getDoctor().processHealthItem(chart);
    }

    public void writeToFile() {
        // Your code here
        //This method will write a new line of chart data to a patient's data file. If such a file does
        //not exist, this method will create a new file using the HI + ID +.csv structure listed above.
        try (PrintWriter chartWriter = new PrintWriter(filename)) {
            for ( HealthItem healthItem: chart) {
                chartWriter.write(healthItem.toCSV() + "\n");
            }
        }
        catch(IOException e){e.printStackTrace();}
    }

    public  ArrayList<HealthItem> getChart() {
        //This method is supposed to add the doctor data item assigned to the patient associated with each
        //specific chart. The item to be stored here is the doctor ID. This id will be the first line
        //in the chart file.
        return chart;
    }

    //Setters and Getters for this class
    public Doctor getDoctor() {return doctor;}

    public void setDoctor(Doctor doctor) {this.doctor = doctor;}

    public String getFilename() {return filename;}

    public void setFilename(String filename) {this.filename = filename;}

    public void setChart(ArrayList<HealthItem> chart) {this.chart = chart;}


    public String getId() {return id;}

    public void setId(String id) {this.id = id;}
}
