package com.example.homework_3.ChartPackage;

//import DoctorPackage.Doctor;
import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;

public class HealthItem {
    //Based off the provided UML diagram, this class is connected to the chart class through composition.
    //This class is what enables the chart class to store information for the patient(s) as
    //the healthcare worker sees it. It is the foundation of all the ChartPackage.ChartPackage.HealthItem objects.
    private String id, testName, date, value;
    private Doctor doctor;

    //Default constructor
    public HealthItem( ) {
        id = ""; testName = ""; date = ""; value = "";
    }

    //Overloaded constructor for a healthItem
    public HealthItem(String id, String testName, String date, String value) {
        this.id = id;
        this.testName = testName;
        this.date = date;
        this.value = value;
    }

    //Setters and getters for this class
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return String.format("%5s %20s %15s %20s", id, testName, date, value);
    }

    public String toCSV() {
        return new String(id + "," + testName + "," + date + "," + value);
    }
}
