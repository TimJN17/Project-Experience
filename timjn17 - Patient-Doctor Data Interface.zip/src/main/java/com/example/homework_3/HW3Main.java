// NAME: Timothy Naudet
// AndrewID: tnaudet


package com.example.homework_3;

import com.example.homework_3.ChartPackage.Chart;
import com.example.homework_3.ChartPackage.HealthItem;
import com.example.homework_3.DoctorPackage.Doctor;
import com.example.homework_3.DoctorPackage.DoctorFactory;
import com.example.homework_3.DoctorPackage.DoctorList;
import com.example.homework_3.PatientPackage.Patient;
import com.example.homework_3.PatientPackage.PatientList;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.swing.text.Element;
import javax.swing.text.TabExpander;
//import javax.swing.text.TableView;
import java.awt.*;
import java.io.File;
import java.util.*;
import static javafx.application.Application.launch;

public class HW3Main extends Application {
    // Member Data
    public static DoctorList doctorList;
    public static Scanner scanner = new Scanner(System.in);
    private static int MENU_MAX = 10;
    public static String patientFile = "patients.csv";
    public static String doctorFile = "doctors.csv";
    public static PatientList patientList;
    private static PatientList patientMap;
    public static Patient patient;
    public static Doctor doctor;
    public static int patientCount1; public static int doctorCount1;
    private static boolean firstChart = true;
    private static boolean dListChanged = false;
    private static boolean pListChanged = false;

    // Menu Objects
    // new Dialog<String>()
    private static MenuItem aboutOption = new MenuItem("About");
    private static MenuItem openDoctorFile = new MenuItem("Open Doctor File");
    private static MenuItem openPatientFile = new MenuItem("Open Patient File");
    private static MenuItem saveDataFiles = new MenuItem("Save Data Files");
    private static MenuItem quit = new MenuItem("Quit");
    private static Menu menu = new Menu("File");
    private static MenuBar menuBar; // = new MenuBar();
    private static FileChooser fileChooser = new FileChooser();

    // Buttons
    private static Button clearFieldButton = new Button("Clear"),
            newPatientButton = new Button("New Patient"),
            patientSearchButton = new Button("Search"),
            newDoctorButton = new Button("Add Doctor"),
            newHealthItemButton = new Button ("Add Health Item");

    // Labels
    private static Label
            //Patient Labels
            patientsLoadedBoxLabel = new Label("# Patients Loaded"),
            patientIDBoxLabel = new Label("Patient ID"),
            patientLNameBoxLabel = new Label("Last Name"),
            patientFNameBoxLabel = new Label("First Name"),
            patientAddressBoxLabel = new Label("Address"),
            patientAgeBoxLabel = new Label("Age"),
            patientDoctorIDBoxLabel = new Label("Doctor ID"),
            patientNewPatientBoxLabel = new Label("Enter Data Above"),
            patientSearchBoxLabel = new Label("Search"),
            patientVBoxTitleLabel = new Label("Patients"),
            //Chart Labels (chartTitleLabel to be named in the patient Search button)
            chartTitleLabel = new Label(),
            chartAddNewItemLabel = new Label("Add New Health Item"),
            chartTestLabel = new Label("Test"),
            chartDateLabel = new Label ("Date"),
            chartValueLabel = new Label("Value"),
            //Doctor Labels
            doctorVBoxTitleLabel = new Label("Doctor List"),
            doctorAddDoctorTitleLabel = new Label("Add New Doctor"),
            doctorSpecialtyComboBoxLabel = new Label("Specialty"),
                    doctorDoctorNameLabel = new Label("Name"),
                    doctorDoctorIDLabel = new Label("Doctor ID");

    // Text fields
    private static TextField
            // Patient text fields
            patientsLoadedField = new TextField(),
            patientIDField = new TextField(),
            patientFNameField = new TextField(),
            patientLNameField = new TextField(),
            patientAddressField = new TextField(),
            patientAgeField = new TextField(),
            patientDoctorIdField = new TextField(),
            patientSearchBoxField = new TextField(),
            // Chart text fields
            chartTestField = new TextField(),
            chartDateField = new TextField(),
            chartValueField = new TextField(),
            // DoctorText Fields
            doctorDoctorNameField = new TextField(),
            doctorDoctorIDField = new TextField();

    // Text Areas
    private static TextArea doctorListArea = new TextArea("No Doctors Loaded");

    // Methods to clear text fields
    public static void clearPatientFields() {
        patientIDField.setText("");
        patientFNameField.setText("");
        patientLNameField.setText("");
        patientAddressField.setText("");
        patientAgeField.setText("");
        patientDoctorIdField.setText("");
        patientSearchBoxField.setText("");
    }
    public static void clearChartFields(){
        chartTestField.setText("");
        chartDateField.setText("");
        chartValueField.setText("");
    }

    // comboBoxes
    private static ComboBox doctorSpecialtyComboBox = new ComboBox();

    // HBoxes
    private static HBox
            // Patient HBoxes
            patientsLoadedBox = new HBox(),
            patientIDBox = new HBox(),
            patientLNameBox = new HBox(),
            patientFNameBox = new HBox(),
            patientAddressBox = new HBox(),
            patientAgeBox = new HBox(),
            patientDoctorIDBox = new HBox(),
            patientNewPatientBox = new HBox(),
            patientSearchBox = new HBox(),
            // Chart HBoxes
            chartTitleLabelBox = new HBox(),
            chartLabelsBox = new HBox(),
            chartHealthItemFieldBox = new HBox(),
            // Doctor HBoxes
            //doctorVBoxTitle = new HBox(),
            doctorTextAreaBox = new HBox(),
            doctorAddDoctorLabelBox = new HBox(),
            doctorThreeDropListsBox = new HBox();
            //addDoctorButtonBox = new HBox();

    // VBoxes: Patients and Doctors
    private static VBox menuPatientVbox = new VBox(),
            menuDoctorVBox = new VBox(),
            chartChartDisplayVBox = new VBox();

    // BorderPane
    private static BorderPane openingBorderPane = new BorderPane(),
            chartBorderPane = new BorderPane();

    // TableView
    private static TableView chartTable = new TableView();

    // This method launches the Java FX GUI widgets
    public static void main(String[] args) {
        // located in the start( ) method
        launch(args);
    }

    // This method loads the GUI Widgets
    public void start(Stage primaryStage) throws Exception{
        // 'setUpChartInfo(); is called here to avoid any duplicate children errors in the chart scenes
        setUpChartInfo();
        patientDisplay();
        doctorDisplay();
        setUpMenu(primaryStage);
        openingBorderPane.setTop(menuBar);
        openingBorderPane.setCenter(menuPatientVbox);
        openingBorderPane.setBottom(menuDoctorVBox);
                                             // object, width, height
        Scene scene = new Scene(openingBorderPane, 400, 650);
        //scene.setPa
        primaryStage.setTitle("Patient-Ware V.3");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Set up the patient display info
    public static void setUpPatientInfo(){
        // Patient Labels
        patientVBoxTitleLabel.setAlignment(Pos.CENTER);
        patientVBoxTitleLabel.setFont(Font.font("Consolas", 16));
        patientsLoadedBoxLabel.setMinWidth(100);
        patientIDBoxLabel.setMinWidth(100);
        patientLNameBoxLabel.setMinWidth(100);
        patientFNameBoxLabel.setMinWidth(100);
        patientAddressBoxLabel.setMinWidth(100);
        patientAgeBoxLabel.setMinWidth(100);
        patientDoctorIDBoxLabel.setMinWidth(100);
        patientNewPatientBoxLabel.setMinWidth(100);
                            // insets are positioned as : top, right, bottom, left
        patientNewPatientBoxLabel.setPadding( new Insets (0, 5, 0, 5) );
        patientSearchBoxLabel.setMinWidth(100);
        patientSearchBoxLabel.setPadding(new Insets (0, 5, 0, 5));
        patientNewPatientBoxLabel.setPadding( new Insets(5, 5, 5, 25));
        // Patient Buttons
        newPatientButton.setPadding(new Insets (5, 5, 5, 5));
        patientSearchButton.setPadding( new Insets (5, 5, 5,5) );
        patientSearchBoxField.setText("Search by ID");
        patientSearchBoxField.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                patientSearchBoxField.clear();
            }
        });
        patientsLoadedBox.getChildren().addAll(patientsLoadedBoxLabel, patientsLoadedField);
        patientsLoadedBox.setPadding(new Insets(5, 5, 5, 5));
        patientIDBox.getChildren().addAll(patientIDBoxLabel, patientIDField);
        patientIDBox.setPadding(new Insets(5, 5, 5, 5));
        patientLNameBox.getChildren().addAll(patientLNameBoxLabel, patientLNameField);
        patientLNameBox.setPadding(new Insets(5, 5, 5, 5));
        patientFNameBox.getChildren().addAll(patientFNameBoxLabel, patientFNameField);
        patientFNameBox.setPadding(new Insets(5, 5, 5, 5));
        patientAddressBox.getChildren().addAll(patientAddressBoxLabel, patientAddressField);
        patientAddressBox.setPadding(new Insets(5, 5, 5, 5));
        patientAgeBox.getChildren().addAll(patientAgeBoxLabel, patientAgeField);
        patientAgeBox.setPadding(new Insets(5, 5, 5, 5));
        patientDoctorIDBox.getChildren().addAll(patientDoctorIDBoxLabel, patientDoctorIdField);
        patientDoctorIDBox.setPadding(new Insets(5, 5, 5, 5));
        patientNewPatientBox.getChildren().addAll(newPatientButton, patientNewPatientBoxLabel);
        patientNewPatientBox.setPadding(new Insets(5, 5, 5, 5));
        //patientSearchBoxField.setPadding( new Insets (0, 0, 0, ));
        patientSearchBox.getChildren().addAll(patientSearchButton, patientSearchBoxField);
        patientSearchBox.setPadding(new Insets(5, 5, 5, 5));
        patientSearchBox.setSpacing(55);
        menuPatientVbox.getChildren().addAll(patientVBoxTitleLabel, patientsLoadedBox, patientIDBox, patientLNameBox,
                patientFNameBox, patientAddressBox, patientAgeBox, patientDoctorIDBox,
                patientNewPatientBox, patientSearchBox);
        menuPatientVbox.setAlignment(Pos.TOP_CENTER);
        menuPatientVbox.setPadding( new Insets(10, 20, 20 ,20));
    }

    // need to display the patient info
    public static void patientDisplay(){
        setUpPatientInfo();
        patientsLoadedField.setText("0");
        if ( patientIDField.getText().equals("") || patientLNameField.getText().equals("")
                || patientFNameField.getText().equals("")
                || patientAddressField.getText().equals("")
                || patientAgeField.getText().equals("")
                || patientDoctorIdField.getText().equals("")) {
            newPatientButton.setDisable(true);
            newPatientButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    Alert message = new Alert(Alert.AlertType.INFORMATION);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("Patient " + patient.getId() + " not added to patientList.\n" +
                            "Enter all data fields properly.\n" +
                            "There can be no missing data.");
                    message.showAndWait();
                }
            });
        }
        if ( !patientIDField.getText().equals("") && !patientLNameField.getText().equals("")
                && !patientFNameField.getText().equals("")
                && !patientAddressField.getText().equals("")
                && !patientAgeField.getText().equals("")
                && !patientDoctorIdField.getText().equals("")) { newPatientButton.setDisable(false); }
        newPatientButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                try {
                    patient = new Patient( patientFNameField.getText(),
                            patientLNameField.getText(), patientIDField.getText(),
                            patientAddressField.getText(), Integer.parseInt(patientAgeField.getText()),
                            doctorList.findByID(patientDoctorIdField.getText()));
                } catch (NullPointerException e) {
                    Alert message = new Alert(Alert.AlertType.ERROR);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("Patient ID ERROR.\n" +
                            "This is the most important field to enter properly.");
                    message.showAndWait();
                } catch (NumberFormatException e) {
                    Alert message = new Alert(Alert.AlertType.ERROR);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("Error with the patient ID.\n" +
                            "Make sure the ID entered is only numerical digits.\n " +
                            "No decimals, symbols, or letters of any kind.\n");
                    message.showAndWait();
                }
                if (patientFNameField.getText().isEmpty() || patientLNameField.getText().isEmpty()
                        || patientIDField.getText().isEmpty() || patientAddressField.getText().isEmpty()
                || patientAgeField.getText().isBlank()) {
                    clearPatientFields();
                    Alert message = new Alert(Alert.AlertType.ERROR);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("That patient not added to patientList.\n" +
                            "Enter all data fields properly.\n" +
                            "There can be no missing data.");
                    message.showAndWait(); // maybe change this to show and wait??
                } else if (patientList.findByID(patient.getId()) == null) {
                    // Must check for the null condition so that the patient is a new patient
                    patientList.append(patient);
                    Alert message = new Alert(Alert.AlertType.INFORMATION);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("Patient " + patient.getId() + " added to patientList.\n");
                    message.showAndWait();
                    pListChanged = true;
                    clearPatientFields();
                    patientsLoadedField.setText(String.valueOf(patientList.patientListCount()));
                } else if (patientList.findByID(patient.getId()) != null) {
                    Alert message = new Alert(Alert.AlertType.ERROR);
                    message.setTitle("Error");
                    message.setHeaderText("Error");
                    message.setContentText("Patient " + patient.getId() + " already exists.\n");
                    message.showAndWait();
                    clearPatientFields();
                }
            }
        });
        patientSearchButton.setDisable(true);
        patientSearchButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (patientList.findByID(patientSearchBoxField.getText()) != null ) {
                    patient = null;
                    patient = patientList.findByID(patientSearchBoxField.getText());
                    patientIDField.setText(patient.getId());
                    patientFNameField.setText(patient.getFirstName());
                    patientLNameField.setText(patient.getLastName());
                    patientAddressField.setText(patient.getAddress());
                    patientAgeField.setText(String.valueOf(patient.getAge()));
                    patientDoctorIdField.setText(patient.getDoctor().getId());
                    chartTitleLabel.setText("");
                    // this call did not remove the errors here: setUpChartInfo();
                    // NOTE: The patient has a getter method called'.getChart()' that returns a Chart object.
                    // The Chart class then has a getter method
                    // with the same appellate '.getchart' that returns an arrayList. This arrayList,
                    // called 'chart' has the healthItems for each patient. These are below.
                    for (HealthItem h : patient.getChart().getChart()) {
                        chartTable.getItems().add(h);
                    }
                    chartDisplay();
                } else if (patientList.findByID(patientSearchBoxField.getText()) == null) {
                    chartTitleLabel.setText("");
                    Alert message = new Alert(Alert.AlertType.ERROR);
                    message.setTitle("Error");
                    message.setHeaderText("Error: ");
                    message.setContentText("That patient not found.");
                    message.showAndWait();
                }
            }
        });
    }
    // SetUpChart Info
    public static void setUpChartInfo () {
        // Chart text fields and labels and boxes
        chartTestField.setText("Test-Type");
        chartDateField.setText("DD-MM-YYYY");
        chartValueField.setText("Test Value");
        chartTitleLabel.setFont(Font.font(16));
        chartAddNewItemLabel.setMinWidth(100);
        chartAddNewItemLabel.setAlignment(Pos.CENTER);
        chartTestLabel.setMinWidth(100);
        chartDateLabel.setMinWidth(100);
        chartValueLabel.setMinWidth(100);
        chartTestField.setMaxWidth(100);
        chartDateField.setMaxWidth(100);
        chartValueField.setMaxWidth(100);
        newHealthItemButton.setMinWidth(100);
        chartTitleLabel.setMinWidth(100);
        chartTitleLabelBox.getChildren().addAll(chartTitleLabel);
        chartTitleLabelBox.setAlignment(Pos.CENTER);
        chartLabelsBox.getChildren().addAll(chartTestLabel, chartDateLabel, chartValueLabel);
        chartLabelsBox.setAlignment(Pos.CENTER);
        chartHealthItemFieldBox.getChildren().addAll(chartTestField, chartDateField, chartValueField);
        chartHealthItemFieldBox.setAlignment(Pos.CENTER);
        chartChartDisplayVBox.getChildren().addAll(chartLabelsBox, chartHealthItemFieldBox,
                newHealthItemButton);
        chartChartDisplayVBox.setAlignment(Pos.CENTER);
        // Table Columns for Health Items
        TableColumn<HealthItem, String> chartTestColumn = new TableColumn<>("Test Name");
        chartTestColumn.setMinWidth(100);
        TableColumn<HealthItem, String> chartDateColumn = new TableColumn<>("Test Date");
        chartDateColumn.setMinWidth(100);
        TableColumn<HealthItem, String> chartTestValueColumn = new TableColumn<>("Test Value");
        chartTestValueColumn.setMinWidth(100);
        chartTestColumn.setCellValueFactory(new PropertyValueFactory<>("testName"));
        chartDateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        chartTestValueColumn.setCellValueFactory(new PropertyValueFactory<>("Value"));
        chartTable.getColumns().addAll(chartTestColumn, chartDateColumn, chartTestValueColumn);
        chartTable.setMaxWidth(310);

    }
    // Need to display all info about charts
    public static void chartDisplay (){
        //setUpChartInfo();
        // The call to "setUpChartInfo() is not made because it produces errors when the "ChartDisplay()" method is called
        // in the patient display section.
        chartTitleLabel.setText("Chart for Patient #" + patient.getId());
        newHealthItemButton.setDisable(true);
        // New HealthItem Button actions
        chartTestField.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                chartTestField.clear();
            }
        });
        chartDateField.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                chartDateField.clear();
            }
        });
        chartValueField.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                chartValueField.clear();
            }
        });
        if (!chartTestField.equals("Test-Type") && !chartDateField.equals("DD-MM-YYYY")
                && !chartValueField.equals("Test Result")) { newHealthItemButton.setDisable(false); }
        newHealthItemButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                    HealthItem h = new HealthItem(patient.getId(), chartTestField.getText(),
                            chartDateField.getText(), chartValueField.getText());
                    patient.getChart().getChart();
                    patient.getChart().writeToFile();
                    chartTable.getItems().add(h);
                    Alert message = new Alert(Alert.AlertType.INFORMATION);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("HealthItem Added to the chart for:\n" +
                            "Patient #" + patient.getId());
                    message.showAndWait();
                    chartTable.refresh();
                    clearChartFields();
            }
        });
        if (chartTestField.equals("Test-Type") || chartDateField.equals("DD-MM-YYYY")
                || chartValueField.equals("Test Result")) {
            newHealthItemButton.setOnMouseEntered(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    Alert message = new Alert(Alert.AlertType.ERROR);
                    message.setTitle("ERROR");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("Must enter proper data for each field");
                    message.showAndWait();
                }
            });
        }

        Stage chartStage  = new Stage();
        chartBorderPane.setTop(chartTitleLabelBox);
        chartBorderPane.setCenter(chartTable);
        chartBorderPane.setBottom(chartChartDisplayVBox);
            // object, width, height
        // String sceneName = "scenePatient" + patient.getId();
        //Scene chartScene =
        //Parent root
        chartStage.setTitle("Chart");
        Scene scene = null;
        if (firstChart) {scene = new Scene(chartBorderPane, 500, 500); }
        else { scene = chartBorderPane.getScene(); }
        chartStage.setScene(scene);
        chartStage.show();
        firstChart = false;
    }
    // Need to Set up the Doctor Info
    public static void setUpDoctorInfo(){
        doctorTextAreaBox.getChildren().addAll(doctorListArea);
        doctorTextAreaBox.setMinWidth(350);
        doctorTextAreaBox.setMaxHeight(100);
        doctorSpecialtyComboBoxLabel.setMinWidth(150);
        doctorSpecialtyComboBox.setMinWidth(150);
        doctorDoctorNameLabel.setMinWidth(125);
        doctorDoctorNameField.setMinWidth(125);
        doctorDoctorIDLabel.setMinWidth(75);
        doctorDoctorIDField.setMinWidth(75);
        doctorSpecialtyComboBox.getItems().addAll("Surgeon", "Pediatrician", "Internist");
        doctorSpecialtyComboBox.setVisibleRowCount(3);
        doctorAddDoctorLabelBox.getChildren().addAll(doctorSpecialtyComboBoxLabel, doctorDoctorNameLabel,
                doctorDoctorIDLabel);
        doctorThreeDropListsBox.getChildren().addAll(
                 doctorSpecialtyComboBox, doctorDoctorNameField, doctorDoctorIDField);
        menuDoctorVBox.getChildren().addAll(doctorVBoxTitleLabel, doctorTextAreaBox, doctorAddDoctorTitleLabel,
                doctorAddDoctorLabelBox,
                doctorThreeDropListsBox,  newDoctorButton);
        menuDoctorVBox.setAlignment(Pos.CENTER);
        menuDoctorVBox.setPadding(new Insets(10, 10, 10, 10));
    }

    // Need to display all the doctor info
    public static void doctorDisplay(){
        setUpDoctorInfo();
        if (doctorListArea.getText().equals("No Doctors Loaded")) {
            newDoctorButton.setDisable(true);
        } else {
            newDoctorButton.setDisable(false);
        }
        newDoctorButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if (doctorList.findByID(doctorDoctorIDField.getText()) == null) {
                    doctor = DoctorFactory.createDoctor(doctorSpecialtyComboBox.getValue().toString(),
                            doctorDoctorNameField.getText(), doctorDoctorIDField.getText());
                    doctorList.append(doctor);
                    doctorList.writeToFile();
                    doctorListArea.clear();
                    for (Doctor d : doctorList.getDoctorList()) {
                        //doctorListArea.appendText();
                        doctorListArea.appendText(d.toTextArea() + "\n");
                    }
                    dListChanged = true;
                    Alert message = new Alert(Alert.AlertType.INFORMATION);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("Doctor Successfully Loaded");
                    message.showAndWait();
                } else if (doctorList.findByID(doctorDoctorIDField.getText()) != null) {
                    Alert message = new Alert(Alert.AlertType.INFORMATION);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("That doctor not found.");
                    message.showAndWait();
                }
            }
        });
    }

    public static void setUpMenu(Stage stage){
        // to have a directory that filters on .csv files for any open file
        //The following line allows us to choose a file from a folder on the computer. "." allows
        //us to use the directory of this java program
        menuBar = new MenuBar();
        openPatientFile.setDisable(true);
        saveDataFiles.setDisable(true);
        fileChooser.setInitialDirectory(new File("."));
        fileChooser.setTitle("Open File");
        //This "open file" will appear in the window in which we search for the file
        aboutOption.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Alert message = new Alert(Alert.AlertType.INFORMATION);
                message.setTitle("ABOUT");
                //message.setHeaderText("Message for the user: ");
                message.setContentText("Content made by Tim Naudet");
                message.showAndWait();
            }
        });
        openDoctorFile.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                // might need ot restructure the methods to ensure that
                // the files can be loaded properly instead of name
                File file = fileChooser.showOpenDialog(stage);
                String name = "";
                try {
                    name = file.getName();
                } catch (NullPointerException e) {
                    name = "bad file name";
                    System.out.println(name);
                }
                if (name.equals("doctors.csv")) {
                    doctorListArea.clear();
                    //DoctorList dList = new DoctorList(file.getName());
                    doctorList = new DoctorList(file.getName());
                    doctorList.loadFromFile(file);
                    // doctorListArea.appendText(dList.toTextArea());
                    for (Doctor d : doctorList.getDoctorList()) {
                        doctorListArea.appendText(d.toTextArea() + "\n");
                    }
                    patientSearchButton.setDisable(true);
                    newDoctorButton.setDisable(false);
                    openPatientFile.setDisable(false);
                    saveDataFiles.setDisable(false);
                    doctorCount1 = doctorList.doctorListCount();
                    // doctorListArea.setText(doctorList.getDoctorList().toString());
                } else if (!file.getName().equals("doctors.csv")) {
                    Alert message = new Alert(Alert.AlertType.INFORMATION);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("That file is corrupt.");
                    message.showAndWait();
                }
            }
        });
        openPatientFile.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                File file = fileChooser.showOpenDialog(stage);
                if (file.getName().equals("patients.csv")) {
                    patientList = new PatientList(file.getName());
                    patientList.setDoctorList(doctorList);
                    patientList.loadFromFile(file);
                    patientList.getPatientList();
                    patientCount1 = patientList.patientListCount();
                    patientsLoadedField.setText(String.valueOf(patientList.patientListCount()));
                    saveDataFiles.setDisable(false);
                    patientSearchButton.setDisable(false);
                    newPatientButton.setDisable(false);
                }else if (!file.getName().equals("patients.csv")) {
                    Alert message = new Alert(Alert.AlertType.INFORMATION);
                    message.setTitle("Message");
                    message.setHeaderText("Message for the user: ");
                    message.setContentText("You must select the patient file.");
                    message.showAndWait();
                }
            }
        });
        saveDataFiles.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                doctorList.writeToFile();
                patientList.writeToFile();
            }
        });
        quit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                quitProgram();
            }
        });
        menu.getItems().addAll(aboutOption, openDoctorFile, openPatientFile, saveDataFiles, quit);
        menuBar.getMenus().addAll(menu);
    }

    public static void quitProgram() {
        //"Re-write the patient file only if the patientList has changed."
        //The below loop compares the size of the patient list before any use to the size after use.
        //If the count is different, the patient list is 'writtenToFile' because the file was altered.
        if (dListChanged = true) {
            doctorList.writeToFile();
        }
        if (pListChanged = true) {
            patientList.writeToFile();
        }
        Alert message = new Alert(Alert.AlertType.INFORMATION);
        message.setTitle("Message");
        message.setHeaderText("Message for the user: ");
        message.setContentText("You quit. Files were saved. Goodbye!");
        message.showAndWait();
        System.exit(-1);
    }

}
