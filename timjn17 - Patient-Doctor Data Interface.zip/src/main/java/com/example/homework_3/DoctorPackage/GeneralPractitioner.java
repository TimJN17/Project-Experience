package com.example.homework_3.DoctorPackage;

/*import ChartPackage.Chart;
import ChartPackage.HealthItem;*/
import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;

import java.util.ArrayList;


public abstract class GeneralPractitioner extends Doctor {

    //This class is an abstract class a child class of the doctor class. It has two children-- internist and pediatrician.

    protected String specialty, name, id;

    public GeneralPractitioner() {
        super();
    }

    public GeneralPractitioner(String specialty, String name, String id) {
        super(specialty, name, id);
        this.specialty = specialty;
        this.name = name;
        this.id = id;
    }

    public abstract void processHealthItem (ArrayList<HealthItem> chart);
}
