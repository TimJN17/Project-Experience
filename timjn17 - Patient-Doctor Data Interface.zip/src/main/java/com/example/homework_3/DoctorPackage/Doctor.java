package com.example.homework_3.DoctorPackage;

/*import ChartPackage.Chart;
import ChartPackage.HealthItem;*/
import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;

import java.util.ArrayList;

public abstract class Doctor {

    //This class is an abstract class and the overall parent class for GeneralPractitioner, Surgeon, Internist,
    // and Pediatrician. This class holds the basic info for those classes.

    protected String specialty, name, id;

    public Doctor() {
        //This constructor for the Doctor class
        this.specialty = "";
        this.name = "";
        this.id ="";
    }

    public Doctor(String specialty, String name, String id) {
        //The overloaded constructor for the Doctor class and subsequent doctor objects.
        this.specialty = specialty;
        this.name = name;
        this.id = id;
    }

    //The below method is the abstract method for the doctor class and all of its "child" classes.
    public abstract void processHealthItem (ArrayList<HealthItem> chart);

    //The below methods are the getters and setters for the doctor class.
    public String getSpecialty() { return specialty; }

    public void setSpecialty(String specialty) { this.specialty = specialty; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getId() { return id; }

    public void setId(String id) { this.id = id; }

    public String toCSV() {
        return new String(specialty + "," + name + "," + id);
    }

    //To strong for all doctor objects.
    @Override
    public String toString() {
        return "   " + specialty + "   " + name + "   " +id ;
    }

    public String toTextArea() {
       return String.format("%-20s %15s %10s", getSpecialty(), getName(), getId());
    }
}
