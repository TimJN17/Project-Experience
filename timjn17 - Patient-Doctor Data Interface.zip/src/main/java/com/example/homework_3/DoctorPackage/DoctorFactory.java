package com.example.homework_3.DoctorPackage;
import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;

public class DoctorFactory {

    //This class houses the doctorFactory method that receives three strings as parameters and creates three different
    //types of doctor objects based around those inputs.

    public static Doctor createDoctor(String speciality, String name, String id) {
        Doctor doctor = null;
        if (speciality.equals("Surgeon")) {
            doctor = new Surgeon (speciality, name, id);
        }  else if (speciality.equals("Pediatrician")) {
            doctor = new Pediatrician(speciality, name, id);
        } else if (speciality.equals("Internist")) {
            doctor = new Internist(speciality, name, id);
        }
        return doctor;
    }

}
