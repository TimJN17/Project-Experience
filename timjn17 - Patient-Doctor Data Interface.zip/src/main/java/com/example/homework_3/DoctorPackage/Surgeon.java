package com.example.homework_3.DoctorPackage;

/*import ChartPackage.Chart;
import ChartPackage.HealthItem;
import PatientPackage.Patient;*/

import com.example.homework_3.ChartPackage.*;
import com.example.homework_3.DoctorPackage.*;
import com.example.homework_3.PatientPackage.*;
//import javax.print.Doc;
import java.util.ArrayList;
import java.util.Locale;

public class Surgeon extends Doctor {

    //This class is an abstract class a child class of the doctor class. It has two children-- internist and pediatrician.

    protected String specialty, name, id;

    //Default constructor
    public Surgeon() {
        super();
    }

    //Overloaded constructor
    public Surgeon(String specialty, String name, String id) {
        super(specialty, name, id);
        this.specialty = specialty;
        this.name = name;
        this.id = id;
    }

    //This method prints the assigned statement bases solely off the doctor type, not the type of healthItem in the chart
    //ArrayList. This is the case because each patient is only assigned one doctor, and that doctor object is a specific
    //type of doctor, with an assigned prompt to be used.
    public void processHealthItem (ArrayList<HealthItem> chart) {

        for (HealthItem healthItem : chart) {
            if (healthItem.getTestName().equals("MRI") || healthItem.getTestName().toUpperCase().equals("X-RAY")) {
                System.out.println("\n" + name + " will perform the surgery on " +
                        healthItem.getId());
                break;
            }
        }

    }
}
