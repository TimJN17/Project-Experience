package com.example.homework_3.DoctorPackage;

//import PatientPackage.Patient;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class DoctorList {

    //This class is the class for the doctorList arrayList. The doctorList ArrayList holds the doctor objects used for
    //this patientWare interface.

    public static Scanner scanner = new Scanner(System.in);
    private ArrayList<Doctor> doctorList;
    String fileName;
    private Doctor doctor;

    //Overloaded constructor for the DoctorList class
    public DoctorList(String fileName) {
        this.doctorList = new ArrayList<>();
        this.fileName = fileName;
        this.doctor = doctor;
    }

    public void loadFromFile(File file) {
        //This method creates a data array of the strings from the "doctors.csv" file and then appends new Doctor
        //objects into the doctorList ArrayList by using the separate data from the doctors.csv file as the parameters
        //for the doctor objects.
        Scanner fileScanner = null;
        // File newFile = new File(fileName);
        try {
            fileScanner = new Scanner(file);
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] data  = line.split(",");
                Doctor d = DoctorFactory.createDoctor(data[0], data[1], data[2]);
                append(d);
            }
        } catch (FileNotFoundException e) {
            System.out.println("\nDoctor file not found.");
        }
    }

    public void writeToFile() {
        // Your code here
        //This method opens the doctorList arrayList and writes information into a comma separated variable
        //file for each doctor in the list
        try (PrintWriter patientWriter = new PrintWriter(fileName)) {
            for (Doctor doctor : doctorList) {
                patientWriter.write(doctor.toCSV() + "\n");
            }
        }
        catch(IOException e){e.printStackTrace();}
    }

    public void append(Doctor d) {
        // Your code here
        //This simple method simply adds a patient object into the patientList.
        doctorList.add(d);
    }

    public Doctor findByID( String id) {
        Doctor d = null;
        // Your code here
        //This method searches the doctor list for doctor objects by their id.
        for (Doctor doctor: doctorList) {
            if (doctor.getId().equals(id)) {
                return doctor;
            }
        }
        return d;
    }

    public String display() {
        //This method displays every patient object in the patient array list.
        if (doctorList.size() == 0) {
            System.out.println("DoctorPackage.Doctor list is empty");
            return null;
        } else {
            System.out.printf("%15s %10s %10s\n", "Specialty", "Name", "ID");
            // Your code here
            for (Doctor doctor : doctorList) {
                System.out.printf("%15s %10s %10s\n", doctor.getSpecialty(), doctor.getName(), doctor.getId());
            }
        }
        return null;
    }


    // Sortig by speciality Length
    /*public static void sortBySpeciality() {
        int specialityLength = 0;
        Collections.sort(doctorList, new Comparator<Doctor>() {
            @Override
            public int compare(Doctor o1, Doctor o2) {
                specialityLength = o1.getSpecialty().compareTo(o2.getSpecialty());
                return specialityLength;
            }
        });
    }*/

    //Setters and getters for this class.
    public String toTextArea() {
        for (Doctor d : doctorList) {}
        return String.format("%-15s %-10s %-10s", "Specialty", "Name", "ID" + "\n");
    }
    public ArrayList<Doctor> getDoctorList() { return doctorList; }

    public void setDoctorList(ArrayList<Doctor> doctorList) { this.doctorList = doctorList; }

    public int doctorListCount(){
        return doctorList.size();
    }
}
